from django.db import migrations

def forwards(apps, schema_editor):
    Lesson = apps.get_model('courses', 'Lesson')
    VideoContent = apps.get_model('courses', 'VideoContent')
    ArticleContent = apps.get_model('courses', 'ArticleContent')
    ContentType = apps.get_model('contenttypes', 'ContentType')
    # TODO: implement data move from legacy fields
    pass

def backwards(apps, schema_editor):
    pass

class Migration(migrations.Migration):
    dependencies = [ ('courses','0002_module_lesson'), ('contenttypes','__latest__') ]
    operations = [ migrations.RunPython(forwards, backwards) ]
