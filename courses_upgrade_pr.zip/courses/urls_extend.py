# Merge with existing routers in courses/urls.py
# modules_router.register(r'staff', CourseStaffViewSet, basename='course-staff')
# modules_router.register(r'graded-spec', GradedSpecViewSet, basename='course-graded-spec')
# modules_router.register(r'grades', GradeViewSet, basename='course-grades')
