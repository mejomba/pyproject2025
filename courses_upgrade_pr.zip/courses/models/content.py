from django.db import models

class VideoContent(models.Model):
    file = models.FileField(upload_to='videos/')
    duration = models.PositiveIntegerField(help_text='seconds')
    caption = models.CharField(max_length=200, blank=True)

class ArticleContent(models.Model):
    body = models.TextField()

class ImageContent(models.Model):
    image = models.ImageField(upload_to='images/')
    caption = models.CharField(max_length=200, blank=True)
