from django.conf import settings
from django.db import models

class CourseStaff(models.Model):
    MENTOR = 'mentor'
    ROLE_CHOICES = [(MENTOR, 'Mentor')]
    course = models.ForeignKey('courses.Course', on_delete=models.CASCADE, related_name='staff')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='course_staff')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    joined_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = (('course','user','role'),)
